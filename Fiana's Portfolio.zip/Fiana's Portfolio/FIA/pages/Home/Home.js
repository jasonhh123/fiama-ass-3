function onClick() {
  location.href = '../../pages/about/about.html';
}

function onClick_1() {
  location.href = '../../pages/contact/contact.html';
}

function onClick_2() {
  location.href = '../../pages/portfolio_1/portfolio_1.html';
}

function onClick_3() {
  location.href = '../../pages/Photography_collection/Photography_collection.html';
}