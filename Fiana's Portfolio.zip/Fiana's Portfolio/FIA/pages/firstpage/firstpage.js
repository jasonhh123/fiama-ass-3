function onClick() {
  location.href = '../../pages/Home/Home.html';
}