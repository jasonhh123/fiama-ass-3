function onClick() {
  location.href = '../../pages/Home/Home.html';
}

function onClick_1() {
  location.href = '../../pages/portfolio_1/portfolio_1.html';
}

function onClick_2() {
  location.href = '../../pages/about/about.html';
}

function onClick_3() {
  location.href = '../../pages/contact/contact.html';
}

function onClick_4() {
  location.href = '../../pages/pinan/pinan.html';
}

function onClick_5() {
  location.href = '../../pages/Homepage_car/Homepage_car.html';
}